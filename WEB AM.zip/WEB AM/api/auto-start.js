// ============================================================
//  API: /api/auto-start — Bikin batch email temp + kirim magic link
// ============================================================
const crypto = require('crypto');
const flow = require('./auto-flow');
const AlightMotionAuth = require('./amp-logic');

global.__sessions = global.__sessions || {};

const am = new AlightMotionAuth();

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { domain, count } = req.body || {};
    const total = flow.clampBatch(count);
    const batch = [];

    for (let i = 0; i < total; i++) {
      let acc;
      try {
        acc = await flow.createTempEmail({ domain });
      } catch (err) {
        batch.push({
          sessionId: null, email: null, sent: false,
          error: `Generate gagal: ${err.message}`
        });
        continue;
      }

      let sendOk = true;
      let sendErr = null;
      try {
        const r = await am.sendMagicLink(acc.email);
        if (!r.success) { sendOk = false; sendErr = r.error; }
      } catch (err) {
        sendOk = false; sendErr = err.message;
      }

      const sessionId = crypto.randomBytes(16).toString('hex');
      global.__sessions[sessionId] = {
        email: acc.email,
        domain: acc.domain,
        provider: acc.provider,
        knownIds: [],
        createdAt: Date.now(),
        status: sendOk ? 'SENT' : 'FAILED',
        applied: false,
        orderId: null,
        loginUrl: null,
        sendError: sendErr
      };

      batch.push({
        sessionId,
        email: acc.email,
        domain: acc.domain,
        provider: acc.provider,
        sent: sendOk,
        error: sendErr
      });
    }

    const sentCount = batch.filter(b => b.sent).length;

    return res.json({
      success: true,
      total: batch.length,
      sent: sentCount,
      batch
    });

  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
};