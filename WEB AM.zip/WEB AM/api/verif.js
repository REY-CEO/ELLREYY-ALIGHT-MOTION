const AlightMotionAuth = require('./amp-logic');

const am = new AlightMotionAuth();

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { jobId, link } = req.body || {};
    if (!jobId) return res.status(400).json({ success: false, error: 'Job ID tidak ada.' });
    if (!link || !link.startsWith('http')) {
      return res.status(400).json({ success: false, error: 'Magic Link tidak valid.' });
    }

    let email;
    try {
      email = Buffer.from(jobId, 'base64url').toString('utf8');
    } catch (_) {
      return res.status(400).json({ success: false, error: 'Job ID tidak valid.' });
    }

    if (!email || !email.includes('@')) {
      return res.status(400).json({ success: false, error: 'Sesi kadaluarsa / tidak valid.' });
    }

    const verify = await am.verifyAndFetchProfile(email, link);
    if (!verify.success) {
      return res.status(400).json({ success: false, error: verify.error });
    }

    const premium = await am.applyPremium(verify.idToken);
    if (!premium.success) {
      return res.status(400).json({ success: false, error: premium.error });
    }

    return res.json({
      success: true,
      state: 'SUCCESS',
      email,
      orderId: premium.orderId,
      data: premium.data
    });

  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
};