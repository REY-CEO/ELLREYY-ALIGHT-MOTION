// ============================================================
//  MAS REY — AM Generator Script (Light Version)
// ============================================================

// ── HELPERS (safe DOM access) ───────────────────────────────
const $ = (id) => document.getElementById(id);
function safeSet(el, prop, val) {
  if (el) el[prop] = val;
}

// ── LOADER ──────────────────────────────────────────────────
(function initLoader() {
  const loader = $('loader');
  const statusText = $('loaderStatus');
  if (!loader) return;

  const steps = [
    'Menghubungkan ke server...',
    'Memuat sistem...',
    'Cek koneksi API...',
    'Siap digunakan'
  ];

  let i = 0;
  function nextStep() {
    if (i >= steps.length) {
      setTimeout(() => {
        loader.classList.add('hide');
        setTimeout(() => loader.remove(), 300);
      }, 250);
      return;
    }
    if (statusText) statusText.textContent = steps[i++];
    setTimeout(nextStep, 300);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', nextStep);
  } else nextStep();

  setTimeout(() => {
    if (loader && !loader.classList.contains('hide')) {
      loader.classList.add('hide');
      setTimeout(() => loader.remove(), 300);
    }
  }, 2500);
})();

// ── WELCOME ─────────────────────────────────────────────────
(function initWelcome() {
  const toast = $('welcomeToast');
  const titleEl = $('welcomeTitle');
  const descEl = $('welcomeDesc');
  if (!toast) return;

  const hour = new Date().getHours();
  let greeting = 'Selamat Datang';
  if (hour >= 4 && hour < 11) greeting = 'Selamat Pagi';
  else if (hour >= 11 && hour < 15) greeting = 'Selamat Siang';
  else if (hour >= 15 && hour < 18) greeting = 'Selamat Sore';
  else greeting = 'Selamat Malam';

  if (titleEl) titleEl.textContent = `${greeting}, Sobat MAS REY`;
  if (descEl) descEl.textContent = 'Sistem siap membantu aktivasi premium Anda.';

  setTimeout(() => {
    toast.classList.add('show');
    setTimeout(() => window.closeWelcome(), 6000);
  }, 2500);
})();

window.closeWelcome = function() {
  const t = $('welcomeToast');
  if (!t) return;
  t.classList.remove('show');
  setTimeout(() => t.remove(), 400);
};

// ── THEME ───────────────────────────────────────────────────
const THEMES = ['yellow', 'blue', 'pink', 'purple', 'lime', 'dark'];
const THEME_LABELS = { yellow:'Kuning', blue:'Biru', pink:'Pink', purple:'Ungu', lime:'Lime', dark:'Gelap' };

function applyTheme(name) {
  document.body.classList.remove(...THEMES.map(t => 'theme-' + t));
  document.body.classList.add('theme-' + name);
  localStorage.setItem('masrey_theme', name);
  updateThemeBtn(name);
}

function updateThemeBtn(name) {
  const btn = $('themeBtn');
  if (!btn) return;
  const icons = {
    yellow:'fa-sun', blue:'fa-droplet', pink:'fa-heart',
    purple:'fa-star', lime:'fa-leaf', dark:'fa-moon'
  };
  btn.innerHTML = `<i class="fas ${icons[name] || 'fa-palette'}"></i>`;
}

window.cycleTheme = function() {
  const current = localStorage.getItem('masrey_theme') || 'yellow';
  const idx = THEMES.indexOf(current);
  const next = THEMES[(idx + 1) % THEMES.length];
  applyTheme(next);
  log(`[THEME] Tema diubah: ${THEME_LABELS[next]}`);
};

(function initTheme() {
  const saved = localStorage.getItem('masrey_theme') || 'yellow';
  applyTheme(saved);
})();

// ── DASHBOARD ───────────────────────────────────────────────
(function initDashboard() {
  const timeEl = $('dashTime');
  const dayEl = $('dashDay');
  const dateEl = $('dashDate');
  const statusEl = $('dashStatus');
  const dashDot = $('dashDot');
  if (!timeEl) return;

  const DAYS = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
  const MONTHS = ['Januari','Februari','Maret','April','Mei','Juni',
                  'Juli','Agustus','September','Oktober','November','Desember'];

  function tick() {
    const now = new Date();
    timeEl.textContent = now.toLocaleTimeString('id-ID', { hour12: false });
    if (dayEl) dayEl.textContent = DAYS[now.getDay()];
    if (dateEl) dateEl.textContent = `${now.getDate()} ${MONTHS[now.getMonth()]} ${now.getFullYear()}`;
  }
  tick();
  setInterval(tick, 1000);

  function updateStatus() {
    const online = navigator.onLine;
    if (statusEl) statusEl.textContent = online ? 'Online' : 'Offline';
    if (dashDot) {
      dashDot.classList.toggle('offline', !online);
    }
  }
  updateStatus();
  window.addEventListener('online', updateStatus);
  window.addEventListener('offline', updateStatus);
  setInterval(updateStatus, 5000);
})();

// ── API & TERMINAL ──────────────────────────────────────────
const API_BASE = '';
const terminalLog = $('terminalLog');

function log(text) {
  if (!terminalLog) return;
  const line = document.createElement('div');
  line.textContent = text;
  terminalLog.appendChild(line);
  if (terminalLog.children.length > 20) terminalLog.removeChild(terminalLog.firstChild);
  terminalLog.scrollTop = terminalLog.scrollHeight;
}

// ── MODE SWITCH ─────────────────────────────────────────────
window.switchMode = function(mode) {
  const isAuto = mode === 'auto';
  safeSet($('panelManual'), 'style', isAuto ? 'none' : 'block');
  safeSet($('panelAuto'), 'style', isAuto ? 'block' : 'none');
  const tabM = $('tabManual');
  const tabA = $('tabAuto');
  if (tabM) tabM.classList.toggle('active', !isAuto);
  if (tabA) tabA.classList.toggle('active', isAuto);
};
// workaround safeSet for style (karena objek style hanya bisa di-set via .display)
function safeSet(el, prop, val) {
  if (!el) return;
  if (prop === 'style') { el.style.display = val; }
  else el[prop] = val;
}

window.switchSubTab = function(tab) {
  const isSend = tab === 'send';
  safeSet($('subPanelSend'), 'style', isSend ? 'block' : 'none');
  safeSet($('subPanelVerif'), 'style', isSend ? 'none' : 'block');
  const sTabSend = $('subTabSend');
  const sTabVerif = $('subTabVerif');
  if (sTabSend) sTabSend.classList.toggle('active', isSend);
  if (sTabVerif) sTabVerif.classList.toggle('active', !isSend);
};

// ── MODE MANUAL ─────────────────────────────────────────────
let currentJobId = null;
const emailInput = $('emailInput');
const magicInput = $('magicInput');
const sendBtn = $('sendBtn');
const activateBtn = $('activateBtn');
const btnText = $('btnText');
const msgBox = $('msgBox');

function showMsg(type, text) {
  if (!msgBox) return;
  const icons = { success: 'fa-circle-check', error: 'fa-circle-exclamation', info: 'fa-info-circle' };
  msgBox.className = `message ${type} show`;
  msgBox.innerHTML = `<i class="fas ${icons[type] || 'fa-info-circle'}"></i><span>${text}</span>`;
}
function hideMsg() { if (msgBox) msgBox.className = 'message'; }

function checkForm() {
  if (!activateBtn || !magicInput) return;
  const ok = currentJobId && magicInput.value.trim().startsWith('http');
  activateBtn.disabled = !ok;
}
if (magicInput) magicInput.addEventListener('input', checkForm);

if (sendBtn) sendBtn.addEventListener('click', async () => {
  const email = emailInput ? emailInput.value.trim() : '';
  if (!email || !email.includes('@')) {
    showMsg('error', 'Masukkan email yang valid dulu ya.');
    if (emailInput) emailInput.focus();
    return;
  }
  hideMsg();
  sendBtn.disabled = true;
  sendBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Mengirim...';
  log(`[SEND] Mengirim magic link ke ${email}...`);

  try {
    const res = await fetch(`${API_BASE}/api/send`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email }),
    });
    const data = await res.json();
    if (!data.success) throw new Error(data.error || 'Gagal kirim magic link.');

    currentJobId = data.jobId;
    showMsg('success', data.message || 'Magic Link terkirim! Cek inbox email kamu.');
    log(`[OK] JobId: ${data.jobId.slice(0, 12)}...`);

    sendBtn.innerHTML = '<i class="fas fa-check"></i> Terkirim';
    checkForm();
  } catch (err) {
    showMsg('error', err.message || 'Terjadi kesalahan.');
    log(`[ERROR] ${err.message}`);
    sendBtn.disabled = false;
    sendBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Kirim Magic Link';
  }
});

if (activateBtn) activateBtn.addEventListener('click', async () => {
  const link = magicInput ? magicInput.value.trim() : '';
  if (!currentJobId) { showMsg('error', 'Tekan Kirim dulu.'); return; }
  if (!link.startsWith('http')) { showMsg('error', 'Link harus berupa URL lengkap.'); return; }

  hideMsg();
  activateBtn.disabled = true;
  if (btnText) btnText.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Memproses...';
  log(`[VERIF] Memverifikasi magic link...`);

  try {
    const res = await fetch(`${API_BASE}/api/verif`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ jobId: currentJobId, link }),
    });
    const data = await res.json();
    if (!data.success) throw new Error(data.error || 'Verifikasi gagal.');

    if (btnText) btnText.innerHTML = '<i class="fas fa-check"></i> Berhasil Diaktifkan!';
    activateBtn.style.background = '#b6f542';
    activateBtn.style.color = '#0a0a0a';
    showMsg('success', `Premium aktif! Order ID: ${data.orderId || '-'}`);
    log(`[SUCCESS] Order ID: ${data.orderId}`);
  } catch (err) {
    showMsg('error', err.message || 'Gagal aktivasi.');
    log(`[ERROR] ${err.message}`);
    activateBtn.disabled = false;
    if (btnText) btnText.innerHTML = 'Verifikasi &amp; Aktifkan';
  }
});

// ── MODE BULK ───────────────────────────────────────────────
const autoBtn = $('autoBtn');
const autoProgress = $('autoProgress');
const msgBoxAuto = $('msgBoxAuto');
const batchList = $('batchList');
const batchSummary = $('batchSummary');
const bulkActions = $('bulkActions');
const batchCountEl = $('batchCount');

const MAX_QTY = 5;

window.changeQty = function(delta) {
  if (!batchCountEl) return;
  let val = parseInt(batchCountEl.value) || 1;
  val += delta;
  if (val < 1) val = 1;
  if (val > MAX_QTY) val = MAX_QTY;
  batchCountEl.value = val;
};

function showMsgAuto(type, text) {
  if (!msgBoxAuto) return;
  const icons = { success: 'fa-circle-check', error: 'fa-circle-exclamation', info: 'fa-info-circle' };
  msgBoxAuto.className = `message ${type} show`;
  msgBoxAuto.innerHTML = `<i class="fas ${icons[type] || 'fa-info-circle'}"></i><span>${text}</span>`;
}

let bulkState = { running: false, results: [] };

function createBulkCard(index) {
  const el = document.createElement('div');
  el.id = `bulk-card-${index}`;
  el.className = 'bulk-account-card';
  el.innerHTML = `
    <div class="bulk-account-head">
      <div class="num">AKUN ${index + 1}</div>
      <span class="tag load">proses...</span>
    </div>
    <div class="bulk-account-email email-line">—</div>
    <div class="bulk-account-pass pass-line" style="display:none;"></div>
    <div class="bulk-account-inbox inbox-line" style="display:none;"></div>
    <div class="bulk-account-actions action-line"></div>
  `;
  batchList.appendChild(el);
  return el;
}

function updateBulkCard(index, data) {
  const el = document.getElementById(`bulk-card-${index}`);
  if (!el) return;
  const tag = el.querySelector('.tag');
  const emailLine = el.querySelector('.email-line');
  const passLine = el.querySelector('.pass-line');
  const inboxLine = el.querySelector('.inbox-line');
  const actionLine = el.querySelector('.action-line');

  const { status, email, password, inboxUrl } = data;

  if (status === 'progress') {
    tag.className = 'tag load';
    tag.textContent = 'proses...';
    emailLine.textContent = email || '—';
    passLine.style.display = 'none';
    inboxLine.style.display = 'none';
    actionLine.innerHTML = '';
  } else if (status === 'ready') {
    tag.className = 'tag ok';
    tag.textContent = 'PREMIUM';
    emailLine.innerHTML = `<b>Email:</b> ${email}`;
    passLine.style.display = 'block';
    passLine.innerHTML = `<b>Pass:</b> ${password}`;
    inboxLine.style.display = 'block';
    inboxLine.innerHTML = `Inbox: <a href="${inboxUrl}" target="_blank">${inboxUrl}</a>`;
    actionLine.innerHTML = `
      <button class="btn-open" onclick="window.open('${inboxUrl}','_blank')">
        <i class="fas fa-inbox"></i> Inbox
      </button>
      <button class="btn-copy" onclick="copyText('${email}')">
        <i class="fas fa-copy"></i> Email
      </button>
      <button class="btn-copy" onclick="copyText('${password}')">
        <i class="fas fa-key"></i> Pass
      </button>
    `;
  } else if (status === 'error') {
    tag.className = 'tag err';
    tag.textContent = 'GAGAL';
    emailLine.textContent = email || '—';
    passLine.style.display = 'none';
    inboxLine.style.display = 'none';
    actionLine.innerHTML = '';
  }
}

window.copyText = function(text) {
  navigator.clipboard.writeText(text).then(() => log(`[COPY] ${text}`));
};

if (autoBtn) autoBtn.addEventListener('click', async () => {
  if (bulkState.running) return;

  const domain = document.getElementById('domainSelect').value;
  let count = parseInt(batchCountEl.value) || 1;
  if (count > MAX_QTY) count = MAX_QTY;
  if (count < 1) count = 1;

  bulkState = { running: true, results: [] };

  autoBtn.disabled = true;
  autoBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Memproses...';
  msgBoxAuto.className = 'message';
  autoProgress.style.display = 'block';
  bulkActions.classList.remove('show');
  batchList.innerHTML = '';
  batchSummary.textContent = `Berhasil: 0 akun`;

  showMsgAuto('info', `Memproses ${count} akun premium (instan)...`);
  for (let i = 0; i < count; i++) createBulkCard(i);
  log(`[BULK] Memproses ${count} akun...`);

  try {
    const res = await fetch(`${API_BASE}/api/auto-start`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ domain, count }),
    });

    const text = await res.text();
    let data;
    try { data = JSON.parse(text); }
    catch { throw new Error(`Server error (${res.status}): ${text.slice(0, 80)}`); }

    if (!data.success) throw new Error(data.error || 'Gagal start.');

    let okCount = 0;
    data.batch.forEach((acc, i) => {
      const inboxUrl = acc.email ? `https://emailnator.com/inbox/${acc.email}` : '';
      if (acc.premiumApplied && acc.email && acc.password) {
        updateBulkCard(i, {
          status: 'ready',
          email: acc.email,
          password: acc.password,
          inboxUrl
        });
        log(`[BULK ${i + 1}] PREMIUM — ${acc.email}`);
        bulkState.results.push({ ok: true, email: acc.email, password: acc.password, inboxUrl });
        okCount++;
      } else {
        updateBulkCard(i, { status: 'error', email: acc.email });
        log(`[BULK ${i + 1}] GAGAL — ${acc.error || 'unknown'}`);
        bulkState.results.push({ ok: false, email: acc.email, error: acc.error });
      }
    });

    const fail = count - okCount;
    batchSummary.textContent = `Berhasil: ${okCount} akun${fail > 0 ? ` (${fail} gagal)` : ''}`;
    bulkActions.classList.add('show');
    showMsgAuto('success', `Selesai — ${okCount}/${count} akun premium siap login.`);
    log(`[BULK] Selesai. ${okCount} premium, ${fail} gagal.`);

  } catch (err) {
    log(`[BULK] ERROR: ${err.message}`);
    showMsgAuto('error', err.message);
    for (let i = 0; i < count; i++) updateBulkCard(i, { status: 'error' });
  }

  autoBtn.disabled = false;
  autoBtn.innerHTML = '<i class="fas fa-bolt"></i> Generate Sekarang';
  bulkState.running = false;
});

window.copyAllEmails = function() {
  const rows = bulkState.results.filter(r => r.ok);
  if (!rows.length) { showMsgAuto('error', 'Belum ada akun berhasil.'); return; }
  const text = rows.map(r => `${r.email} | ${r.password}`).join('\n');
  navigator.clipboard.writeText(text).then(() => {
    showMsgAuto('success', `${rows.length} akun disalin (email | password).`);
    log('[COPY ALL] Semua akun disalin.');
  });
};

window.downloadTxt = function() {
  const rows = bulkState.results.filter(r => r.ok);
  if (!rows.length) { showMsgAuto('error', 'Belum ada akun berhasil.'); return; }

  let content = `MAS REY — Daftar Akun Premium\n`;
  content += `Tanggal: ${new Date().toLocaleString('id-ID')}\n`;
  content += `${'='.repeat(45)}\n\n`;

  rows.forEach((r, i) => {
    content += `#${i + 1}\n`;
    content += `Email    : ${r.email}\n`;
    content += `Password : ${r.password}\n\n`;
  });

  content += `Cara login ke Alight Motion:\n`;
  content += `1. Buka app Alight Motion\n`;
  content += `2. Pilih Sign In with Email\n`;
  content += `3. Masukkan email + password di atas\n`;
  content += `4. Premium langsung aktif\n`;

  const blob = new Blob([content], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `mas-rey-premium-${Date.now()}.txt`;
  a.click();
  URL.revokeObjectURL(url);

  log('[DOWNLOAD] File .txt diunduh.');
};

window.addEventListener('load', () => {
  log('[READY] Sistem siap.');
});